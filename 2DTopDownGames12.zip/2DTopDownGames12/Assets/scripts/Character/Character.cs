using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    [Header("����")]
    [SerializeField]protected float maxHealth;

    [SerializeField] protected float currentHealth;

    [Header("�޵�")]
    public bool invulnerable;
    public float invulnerableDuration;//�޵�ʱ��

    protected virtual void OnEnable()
    {
        currentHealth = maxHealth;
    }

    public virtual void TakeDamage(float damage)
    {
        if (invulnerable)
            return;

        currentHealth -= damage;
        StartCoroutine(nameof(InvulnerableCoroutine));//�����޵�ʱ��Э��
        if (currentHealth <= 0f)
        {
            //����
            Die();
        }
    }

    public virtual void Die()
    {
        currentHealth = 0f;
        Destroy(this.gameObject);//���ٸö���
    }

    //�޵�
    protected virtual IEnumerator InvulnerableCoroutine()
    {
        invulnerable = true;

        //�ȴ��޵�ʱ��
        yield return new WaitForSeconds(invulnerableDuration);

        invulnerable = false;
    }
}
