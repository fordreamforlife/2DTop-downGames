using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Character
{
    
    private Color damageColor = Color.red; // ����ʱ����ɫ
    private float damageDuration = 0.2f; // ������ɫ�ĳ���ʱ��
    private SpriteRenderer spriteRenderer; // ��ɫ�� SpriteRenderer ���
    private Color originalColor; // ԭʼ��ɫ

    public float damage;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color;

    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collision.GetComponent<Character>().TakeDamage(damage);
        }
    }

    

    public override void TakeDamage(float damage)
    {
        base.TakeDamage(damage);
        //��������
        StartCoroutine(nameof(DamageEffect));
    }

    IEnumerator DamageEffect()
    {
        spriteRenderer.color = damageColor;
        yield return new WaitForSeconds(damageDuration);
        spriteRenderer.color = originalColor;
    }
}
