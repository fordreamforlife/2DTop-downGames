using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class PlayerController : MonoBehaviour
{
    public InputActions inputActions;
    public Vector2 inputDirection;
    public float moveSpeed;
    private Rigidbody2D rb;
    private SpriteRenderer sr;

    private Animator anim;

    private void Awake()
    {
        inputActions = new InputActions();
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }

    private void OnEnable()
    {
        inputActions.Enable();
    }

    private void OnDisable()
    {
        inputActions.Disable();
    }

    private void Update()
    {
        inputDirection = inputActions.Gameplay.Move.ReadValue<Vector2>();
        //Debug.Log(inputDirection);
        SetAnimation();
    }

    private void FixedUpdate()
    {
        Move();
    }

    void Move()
    {
        rb.velocity = inputDirection * moveSpeed;
        //������ҷ�ת
        if (inputDirection.x < 0)//��
        {
            sr.flipX = true;
        }
        if (inputDirection.x > 0)//��
        {
            sr.flipX = false;
        }
    }
    void SetAnimation()
    {
        anim.SetFloat("Speed", rb.velocity.magnitude);
    }
  
}
