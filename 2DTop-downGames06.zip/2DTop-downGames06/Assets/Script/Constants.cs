using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//������
public static class Constants
{
    public const string TAG_COIN="Coin";
    public const string TAG_EQUIPMENT = "Equipment";
    public const string TAG_KEY = "Key";
    public const string TAG_POTION = "Potion";

}
