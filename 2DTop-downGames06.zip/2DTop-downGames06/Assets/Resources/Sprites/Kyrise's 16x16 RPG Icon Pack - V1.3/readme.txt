
----- Kyrise's Free 16x16 RPG Icon Pack --------------------------------------------
------------------------------------------------------------------------------------
 * ABOUT * 

 Kyrise's Free 16x16 RPG Icon Pack is a free asset pack that contains 350+ sprites  
 (with 70+ unique sprite designs) based in the old school 16-bits RPG Graphics, 
 provided as individual 16x16, 32x32 and 48x48 resolution files and full spritesheet. 
 The best part: it's totally free! Have fun using it :)

 These icons are made with a lot of love, please consider making a donation 
 of any value <3 (https://kyrise.itch.io/kyrises-free-16x16-rpg-icon-pack/purchase)
 
-------------------------------------------------------------------------------------
 * INCLUDED * 

	WEAPONS:	|	 CONSUMABLES:	| 	MISC:
- Swords		| - Potions		|- Arrows
- Staffs		| - Fishes		|- Rings / Necklaces / Amulets
- Bows			| - Candies		|- Gems / Pearls / Crystals / Shards
- Shields		| - Fruits		|- Books
- Spellbooks		| - Cookies		|- Keys
			| - Wine		|- Scrolls
	ARMORS:		|			|- Coins / Ingots
- Helmets / Hats	|			|- Boxes / Gift Boxes
- Armors		|			|- Bones / Skulls
- Gloves		|			|- Candles
- Boots 		|			|- Wood, Flowers, Cotton
			|			|- Cups
------------------------------------------------------------------------------------
* KYRISE PROFILES *

~ Itch.io: https://kyrise.itch.io/
~ Ascension Game Dev: https://www.ascensiongamedev.com/profile/1137-kyrise/

------------------------------------------------------------------------------------
* LICENSE * 

~ License Type: Creative Commons Attribution 4.0 International (CC BY 4.0) 
~ License Terms: https://creativecommons.org/licenses/by/4.0/

------------------------------------------------------------------------------------