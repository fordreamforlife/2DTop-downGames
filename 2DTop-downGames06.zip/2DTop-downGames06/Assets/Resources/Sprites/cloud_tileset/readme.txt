-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY - CLOUD CITY TILESET
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading this tileset! 

This tileset is a FREE release for anybody to download. I created this set as a reward for reaching a goal 
on my Patreon page. Thanks to my wonderful patrons for making this free release possible! patreon.com/finalbossblues

This tileset is a mini-expansion for the Time Fantasy RPG assets. It's compatible with all other graphics that I release 
in my Time Fantasy style. Can also be used as a standalone tileset.

This set includes versions formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as a regular tile-sheet based on a 16x16 grid.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------