using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject uiShowText;

    //����ģʽ
    public static GameManager Instance { get; private set; }

    public int CoinCount { get; private set; }

    public float PlayerCurrentHealth { get; set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else if (Instance != this)
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);//�����³���ʱ�߶���Ϸ���棬��Ҫ���ٸö���
    }

    public void ChangeCoins(int amount)
    {
        CoinCount += amount;
        if (CoinCount < 0)
        {
            CoinCount = 0;
        }
        UICoinCountText.UpateText(CoinCount);//���½��UI�ı�
    }

    //��ʾ��ֵ
    public void ShowText(string str, Vector2 pos, Color color)
    {
        Vector2 screenPosition = Camera.main.WorldToScreenPoint(pos);
        GameObject text =Instantiate(uiShowText, screenPosition, Quaternion.identity);
        text.transform.SetParent(GameObject.Find("HUD").transform);//UI Ԫ�ر�����Canvas������ʾ
        text.GetComponent<UIShowText>().SetText(str,color);
        
    }

    //��������
    public void SaveData()
    {
        PlayerCurrentHealth = Player.Instance.currentHealth;
    }

    //��������
    public void LoadData()
    {
        Player.Instance.currentHealth = PlayerCurrentHealth;
        UICoinCountText.UpateText(CoinCount);//���½��UI�ı�
    }
}
