using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Character : MonoBehaviour
{
    [Header("����")]
    public float maxHealth;

    public float currentHealth;

    [Header("�޵�")]
    public bool invulnerable;
    public float invulnerableDuration;//�޵�ʱ��

    [Header("UI")]
    public UnityEvent<float, float> OnHealthUpdate;

    public UnityEvent OnHurt;
    public UnityEvent OnDie;
    protected virtual void OnEnable()
    {
        currentHealth = maxHealth;
       
    }
    private void Start()
    {
        OnHealthUpdate?.Invoke(maxHealth, currentHealth);//��ʼ��
    }

    public virtual void TakeDamage(float damage)
    {
        if (invulnerable)
            return;
        if (currentHealth -damage > 0f)
        {
            currentHealth -= damage;
            StartCoroutine(nameof(InvulnerableCoroutine));//�����޵�ʱ��Э��
            //ִ�н�ɫ���˶���
            OnHurt?.Invoke();
        }
        else
        {
            //����
            Die();
        }
        //��ʾ�˺���ֵ
        GameManager.Instance.ShowText("-" + damage, transform.position, Color.red);

        OnHealthUpdate?.Invoke(maxHealth, currentHealth);
    }

    //�ָ�Ѫ��
    public virtual void RestoreHealth(float value)
    {
        if (currentHealth == maxHealth) return;//��Ѫ�ͷ���

        if (currentHealth + value > maxHealth)  //��Ѫ���������Ѫ��
        {
            currentHealth = maxHealth;
        }
        else
        {
            currentHealth += value;
        }
        OnHealthUpdate?.Invoke(maxHealth, currentHealth);//����Ѫ��UI
    }

    protected virtual void Die()
    {
        currentHealth = 0f;
        
        //ִ�н�ɫ��������
        OnDie?.Invoke();
    }

    //�޵�
    protected virtual IEnumerator InvulnerableCoroutine()
    {
        invulnerable = true;

        //�ȴ��޵�ʱ��
        yield return new WaitForSeconds(invulnerableDuration);

        invulnerable = false;
    }

 
 

}
