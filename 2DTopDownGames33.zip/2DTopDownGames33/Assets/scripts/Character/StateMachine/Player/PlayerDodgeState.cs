using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// ������ܷ���״̬
/// </summary>
public class PlayerDodgeState : IState
{
    Player player;

    private float dodgeTimer = 0f;
    //���캯��
    public PlayerDodgeState(Player player)
    {
        this.player = player;
    }

    public void OnEnter()
    {

    }
    public void OnUpdate()
    {
        player.anim.SetBool("isDodge", player.isDodging);

        //����
        if (player.isHurt)
        {
            player.TransitionState(PlayerStateType.Hurt);
        }

        if (player.isDodging == false)
        {
            player.TransitionState(PlayerStateType.Idle);
        }
    }

    public void OnFixedUpdate()
    {
        player.Move();
        Dodge();
    }

    public void OnExit()
    {

    }

    //����
    void Dodge()
    {
        if (!player.isDodgeOnCooldown)
        {
            if (dodgeTimer <= player.dodgeDuration)
            {
                //ʩ������
                player.rb.AddForce(player.inputDirection * player.dodgeForce, ForceMode2D.Impulse);

                dodgeTimer += Time.fixedDeltaTime;
            }
            else
            {
                //�������
                player.isDodging = false;
                player.isDodgeOnCooldown = true;
                player.DodgeOnCooldown();//������ȴЭ��
                Debug.Log("��ʼ��ȴ");
                dodgeTimer = 0f;
            }
        }
    }

}
