using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// ��Ҵ���״̬
/// </summary>

public class PlayerIdleState : IState
{
    Player player;

    //���캯��
    public PlayerIdleState(Player player)
    {
        this.player = player;
    }

    public void OnEnter()
    {
        player.anim.Play("PlayerIdle");
    }
    public void OnUpdate()
    {
        //����
        if (player.isHurt)
        {
            player.TransitionState(PlayerStateType.Hurt);
        }

        //�ƶ�
        if (player.inputDirection != Vector2.zero)
        {
            player.TransitionState(PlayerStateType.Move);
        }
        //����
        if (player.isDodging)
        {
            player.TransitionState(PlayerStateType.Dodge);
        }
        //��ս����
        if (player.isMeleeAttack)
        {
            player.TransitionState(PlayerStateType.MeleeAttack);
        }
    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {
 
    }


}
