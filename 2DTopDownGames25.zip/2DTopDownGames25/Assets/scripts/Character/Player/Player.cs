using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//���״̬ö��
public enum PlayerStateType
{ 
    Idle,Move,Dodge,MeleeAttack,Hurt,Death
}

public class Player : Character
{
    [Header("��ȡ�������")]
    public PlayerInput input;
    [Header("�ƶ�")]
    public Vector2 inputDirection;
    public float normalSpeed = 3f;//Ĭ���ٶ�
    public float attackSpeed = 1f;//����ʱ��ҵ��ٶ�
    private float currentSpeed;//��ǰ�ƶ��ٶ�

    [Header("��ս����")]
    public bool isMeleeAttack;
    public float meleeAttackDamage;//��ս�����˺�
    public Vector2 attackSize = new Vector2(1f, 1f);//������Χ�ĳߴ�
    public float offsetX = 1f;//X���ƫ����
    public float offsetY = 1f;//Y���ƫ����
    public LayerMask enemyLayer;//��ʾ����ͼ��
    private Vector2 AttackAreaPos;

    [Header("����")]
    public bool isDodging = false;
    public float dodgeForce;//����
    public float dodgeDuration = 0f;
    public float dodgeCooldown = 2f;//������ȴʱ��
    public bool isDodgeOnCooldown = false;//�����Ƿ�����ȴ��

    [Header("��������")]
    public bool isHurt;
    public bool isDead;

    public SpriteRenderer sr;
    public Rigidbody2D rb;
    public Animator anim;

    private IState currentState;//��ǰ״̬

    //�ֵ�Dictionary<����ֵ>��
    private Dictionary<PlayerStateType, IState> states = new Dictionary<PlayerStateType, IState>();

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anim=GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();

        //ʵ����
        states.Add(PlayerStateType.Idle, new PlayerIdleState(this));
        states.Add(PlayerStateType.Move, new PlayerMoveState(this));
        states.Add(PlayerStateType.Dodge, new PlayerDodgeState(this));
        states.Add(PlayerStateType.MeleeAttack, new PlayerMeleeAttackState(this));
        states.Add(PlayerStateType.Hurt, new PlayerHurtState(this));
        states.Add(PlayerStateType.Death, new PlayerDeathState(this));
        //���ó�ʼ״̬
        TransitionState(PlayerStateType.Idle);
        input.EnableGameplayInput();

    }

    protected override void OnEnable()
    {
        input.onMove += Move;
        input.onStopMove += StopMove;
        input.onDodge += Dodge;
        input.onMeleeAttack += MeleeAttack;
        base.OnEnable();
    }
    private void OnDisable()
    {
        input.onMove -= Move;
        input.onStopMove -= StopMove;
        input.onDodge -= Dodge;
        input.onMeleeAttack -= MeleeAttack;
    }

    //�����л����״̬�ĺ���
    public void TransitionState(PlayerStateType type)
    {
        //��ǰ״̬��Ϊ�գ������˳���ǰ״̬
        if (currentState != null)
        {
            currentState.OnExit();
        }
        //ͨ���ֵ�ļ����ҵ���Ӧ��״̬,������״̬
        currentState = states[type];
        currentState.OnEnter();

    }

    private void Update()
    {
        currentState.OnUpdate();
    }
    private void FixedUpdate()
    {
        currentState.OnFixedUpdate();
    }

    #region �ƶ�
    public void Move(Vector2 moveInput)
    {
        inputDirection = moveInput;
    }

    public void Move()
    {
        //���ݹ���״̬���õ�ǰ�ٶ�
        currentSpeed = isMeleeAttack ? attackSpeed : normalSpeed;

        rb.velocity = inputDirection * currentSpeed;
        //������ҷ�ת
        if (inputDirection.x < 0)//��
        {
            sr.flipX = true;
        }
        if (inputDirection.x > 0)//��
        {
            sr.flipX = false;
        }
    }
    public void StopMove()
    {
        inputDirection = Vector2.zero;
    }

    #endregion

    #region ����
    public void Dodge() {
        if (!isDodging && !isDodgeOnCooldown)
        {
            isDodging = true;
        }
    }
    //������ȴ
    public void DodgeOnCooldown()
    {
        StartCoroutine(nameof(DodgeOnCooldownCoroutine));
    }

    public IEnumerator DodgeOnCooldownCoroutine()
    {
        yield return new WaitForSeconds(dodgeCooldown);
        isDodgeOnCooldown = false; 
        Debug.Log("��ȴ����");
    }

    #endregion

    #region ��ս����

    public void MeleeAttack()
    {
        if (!isDodging)//����ʱ��ֹ����
        {
            anim.SetTrigger("meleeAttack");
            isMeleeAttack = true;
        }
    }

 
    void MeleeAttackAnimEvent(float isAttack)
    {
        //����ƫ����
        AttackAreaPos = transform.position;
        //�Ƿ�ƫת
        offsetX = sr.flipX ? -Mathf.Abs(offsetX) : Mathf.Abs(offsetX);

        AttackAreaPos.x += offsetX;
        AttackAreaPos.y += offsetY;

        Collider2D[] hitColliders = Physics2D.OverlapBoxAll(AttackAreaPos, attackSize, 0f, enemyLayer);

        foreach (Collider2D hitCollider in hitColliders)
        {
            hitCollider.GetComponent<Character>().TakeDamage(meleeAttackDamage * isAttack);
            //hitCollider.GetComponent<EnemyController>().Knockback(transform.position);
        }
    }
    #endregion

    #region ����
    public void PlayerHurt()
    {
        isHurt = true;
    }
    #endregion

    #region ����
    public void PlayerDead()
    {
        isDead = true;
        input.DisableAllInputs();
        TransitionState(PlayerStateType.Death);
    }

    #endregion
    //��ͼ���ڲ���
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(AttackAreaPos, attackSize);
    }
}
