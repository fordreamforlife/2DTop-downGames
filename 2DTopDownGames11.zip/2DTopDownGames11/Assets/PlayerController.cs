using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class PlayerController : MonoBehaviour
{
    public InputActions inputActions;
    public Vector2 inputDirection;
    public float normalSpeed=3f;//Ĭ���ٶ�
    public float attackSpeed = 1f;//����ʱ��ҵ��ٶ�
    private float currentSpeed;//��ǰ�ƶ��ٶ�

    private Rigidbody2D rb;
    private SpriteRenderer sr;

    private Animator anim;
    [Header("��ս����")]
    public bool isMeleeAttack;
    public float moveAttack;

    [Header("����")]
    public bool isDodging = false;
    public float dodgeForce;//����
    private float dodgeTimer = 0f;
    public float dodgeDuration = 0f;
    public float dodgeCooldown = 2f;//������ȴʱ��
    private bool isDodgeOnCooldown = false;//�����Ƿ�����ȴ��

    private void Awake()
    {
        inputActions = new InputActions();
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();

        //��ս����
        inputActions.Gameplay.MeleeAttack.started += MeleeAttack;// ע���¼���������
        //����
        inputActions.Gameplay.Dodge.started += isDodge;
    }



    private void OnEnable()
    {
        inputActions.Enable();
    }

    private void OnDisable()
    {
        inputActions.Disable();
    }

    private void Update()
    {
        inputDirection = inputActions.Gameplay.Move.ReadValue<Vector2>();
        //Debug.Log(inputDirection);
        SetAnimation();
    }

    private void FixedUpdate()
    {
        //�ƶ�
            Move();
        //����
        if (!isMeleeAttack)
            Dodge();
    }

    void Move()
    {
        //���ݹ���״̬���õ�ǰ�ٶ�
        currentSpeed = isMeleeAttack ? attackSpeed : normalSpeed;

        rb.velocity = inputDirection * currentSpeed;
        //������ҷ�ת
        if (inputDirection.x < 0)//��
        {
            sr.flipX = true;
        }
        if (inputDirection.x > 0)//��
        {
            sr.flipX = false;
        }
    }
    void Dodge()
    {
        if (isDodgeOnCooldown)
        {
            dodgeTimer += Time.fixedDeltaTime;
            if (dodgeTimer >= dodgeCooldown)//��ȴʱ�����
            {
                isDodgeOnCooldown = false;
                dodgeTimer = 0f;
                Debug.Log("��ȴ����");
            }
        }

        if (isDodging)
        {
            if (!isDodgeOnCooldown)
            {
                if (dodgeTimer <= dodgeDuration)
                {
                    //ʩ������
                    rb.AddForce(inputDirection * dodgeForce, ForceMode2D.Impulse);

                    dodgeTimer += Time.fixedDeltaTime;
                }
                else
                {
                    //�������
                    isDodging = false;
                    isDodgeOnCooldown = true;
                    Debug.Log("��ʼ��ȴ");
                    dodgeTimer = 0f;
                }
            }
        }
    }

    private void MeleeAttack(InputAction.CallbackContext obj)
    {
        if (!isDodging)
        {
            anim.SetTrigger("meleeAttack");
            isMeleeAttack = true;
        }
    }

    private void isDodge(InputAction.CallbackContext obj)
    {
        if (!isDodging && !isDodgeOnCooldown)
        {
            isDodging = true;
        }
        
    }

    void SetAnimation()
    {
        anim.SetBool("isDodge", isDodging);
        anim.SetFloat("speed", rb.velocity.magnitude);
        anim.SetBool("isMeleeAttack", isMeleeAttack);
    }

}
