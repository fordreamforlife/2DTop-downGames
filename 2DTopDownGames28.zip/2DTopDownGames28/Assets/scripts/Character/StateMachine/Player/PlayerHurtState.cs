using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// �������״̬
/// </summary>
public class PlayerHurtState : IState
{
    Player player;

    private AnimatorStateInfo info;
    //���캯��
    public PlayerHurtState(Player player)
    {
        this.player = player;
    }

    public void OnEnter()
    {
        player.anim.SetTrigger("hurt");
    }
    public void OnUpdate()
    {
        info = player.anim.GetCurrentAnimatorStateInfo(0);
        //����
        if (info.normalizedTime >= .95f)//���������ŵ��ٷ�֮95
        {
            player.TransitionState(PlayerStateType.Idle);
        }
    }
    public void OnFixedUpdate()
    {
        player.Move();
    }
    public void OnExit()
    {
        player.isHurt = false;
    }
}
